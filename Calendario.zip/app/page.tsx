import { CalendarioComponent } from "@/components/calendario";

export default function Home() {
  return (
    <>
    <CalendarioComponent/>
    </>
    
  );
}
